-- Aufgabe 2

-- (a) Wörter aneinanderfügen

join :: [String] -> String



-- (b) Wörter trennen
unjoin :: String -> [String]